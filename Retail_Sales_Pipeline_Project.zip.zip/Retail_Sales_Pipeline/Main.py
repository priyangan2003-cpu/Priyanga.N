
import pandas as pd

print("RETAIL SALES DATA PIPELINE")
print("--------------------------")

data = {
    "Order_ID": [101, 102, 103, 104, 105, 106, 107, 108],
    "Product": [
        "Laptop", "Mobile", "Headphones", "Keyboard",
        "Monitor", "Mouse", "Laptop", "Mobile"
    ],
    "Quantity": [2, 3, 2, 4, 1, 5, 1, 2],
    "Price": [45000, 15000, 2000, 800, 12000, 500, 45000, 15000],
    "City": [
        "Chennai", "Coimbatore", "Madurai", "Chennai",
        "Trichy", "Salem", "Coimbatore", "Madurai"
    ]
}

df = pd.DataFrame(data)

print("\nRAW SALES DATA")
print(df)

print("\nTOTAL RECORDS:", len(df))

# STEP 2: EXTRACT AND SAVE DATA

import os

os.makedirs("data/raw", exist_ok=True)

df.to_csv("data/raw/retail_sales.csv", index=False)

print("\nDATA EXTRACTED SUCCESSFULLY!")
print("CSV FILE CREATED")

# STEP 3: LOAD CSV DATA

sales_df = pd.read_csv("data/raw/retail_sales.csv")

print("\nCSV DATA LOADED SUCCESSFULLY!")

print(sales_df)

print("\nDATASET SHAPE:")
print(sales_df.shape)

print("\nCOLUMN NAMES:")
print(sales_df.columns.tolist())

# STEP 4: DATA QUALITY CHECK

print("\nDATA QUALITY CHECK")

print("\n1. Missing Values:")
print(sales_df.isnull().sum())

print("\n2. Duplicate Records:")
print(sales_df.duplicated().sum())

print("\n3. Data Types:")
print(sales_df.dtypes)

print("\n4. Dataset Information:")
sales_df.info()

# STEP 5: CREATE DIRTY DATA

dirty_df = sales_df.copy()

# Add missing values
dirty_df.loc[2, "City"] = None
dirty_df.loc[4, "Product"] = None

# Add duplicate record
dirty_df = pd.concat(
    [dirty_df, dirty_df.iloc[[0]]],
    ignore_index=True
)

print("\nDIRTY DATASET")
print(dirty_df)

print("\nMissing Values:")
print(dirty_df.isnull().sum())

print("\nDuplicate Records:")
print(dirty_df.duplicated().sum())

print("\nTotal Rows:", len(dirty_df))

# STEP 6: DATA CLEANING

# Remove duplicate records
clean_df = dirty_df.drop_duplicates()

# Fill missing Product
clean_df["Product"] = clean_df["Product"].fillna("Unknown")

# Fill missing City
clean_df["City"] = clean_df["City"].fillna("Unknown")

print("\nDATA CLEANING COMPLETED")

print("\nCleaned Dataset:")
print(clean_df)

print("\nMissing Values After Cleaning:")
print(clean_df.isnull().sum())

print("\nDuplicate Records After Cleaning:")
print(clean_df.duplicated().sum())

print("\nTotal Clean Rows:", len(clean_df))

# STEP 7: DATA TYPE CONVERSION

clean_df["Order_ID"] = clean_df["Order_ID"].astype(int)

clean_df["Quantity"] = clean_df["Quantity"].astype(int)

clean_df["Price"] = clean_df["Price"].astype(float)

print("\nDATA TYPE CONVERSION COMPLETED")

print(clean_df.dtypes)

print("\nUPDATED DATASET:")
print(clean_df)

# STEP 8: SALES AMOUNT CALCULATION

clean_df["Sales_Amount"] = (
    clean_df["Quantity"] * clean_df["Price"]
)

print("\nSALES AMOUNT CALCULATED")

print(clean_df[[
    "Product",
    "Quantity",
    "Price",
    "Sales_Amount"
]])

print("\nTOTAL SALES:")
print(clean_df["Sales_Amount"].sum())

# STEP 9: DATA TRANSFORMATION

# Create Sales Category
clean_df["Sales_Category"] = clean_df["Sales_Amount"].apply(
    lambda x: "High" if x >= 50000 else "Low"
)

# Create Quantity Category
clean_df["Quantity_Category"] = clean_df["Quantity"].apply(
    lambda x: "Bulk" if x >= 3 else "Normal"
)

# Standardize Product Names
clean_df["Product"] = clean_df["Product"].str.title()

print("\nDATA TRANSFORMATION COMPLETED")

print(clean_df[[
    "Product",
    "Sales_Amount",
    "Sales_Category",
    "Quantity_Category"
]])

# STEP 10: PRODUCT-WISE SALES ANALYSIS

product_sales = clean_df.groupby("Product").agg(
    Total_Quantity=("Quantity", "sum"),
    Total_Sales=("Sales_Amount", "sum")
)

print("\nPRODUCT-WISE SALES ANALYSIS")

print(product_sales)

print("\nHIGHEST SALES PRODUCT:")

print(product_sales["Total_Sales"].idxmax())

print("\nLOWEST SALES PRODUCT:")

print(product_sales["Total_Sales"].idxmin())

# STEP 11: CITY-WISE SALES ANALYSIS

city_sales = clean_df.groupby("City").agg(
    Total_Orders=("Order_ID", "count"),
    Total_Quantity=("Quantity", "sum"),
    Total_Sales=("Sales_Amount", "sum")
)

print("\nCITY-WISE SALES ANALYSIS")

print(city_sales)

print("\nHIGHEST SALES CITY:")

print(city_sales["Total_Sales"].idxmax())

print("\nLOWEST SALES CITY:")

print(city_sales["Total_Sales"].idxmin())

# STEP 12: SALES SUMMARY

total_orders = clean_df["Order_ID"].count()

total_quantity = clean_df["Quantity"].sum()

total_sales = clean_df["Sales_Amount"].sum()

average_sales = clean_df["Sales_Amount"].mean()

highest_sale = clean_df["Sales_Amount"].max()

lowest_sale = clean_df["Sales_Amount"].min()

print("\n===== RETAIL SALES SUMMARY =====")

print("Total Orders:", total_orders)

print("Total Quantity:", total_quantity)

print("Total Sales:", total_sales)

print("Average Sales:", average_sales)

print("Highest Sale:", highest_sale)

print("Lowest Sale:", lowest_sale)

# STEP 13: SAVE CLEAN DATASET

import os

os.makedirs("data/processed", exist_ok=True)

clean_df.to_csv(
    "data/processed/clean_retail_sales.csv",
    index=False
)

print("\nCLEAN DATASET SAVED SUCCESSFULLY!")

print("File: data/processed/clean_retail_sales.csv")

print("Total Rows:", len(clean_df))

print("Total Columns:", len(clean_df.columns))

# STEP 14: LOAD DATA INTO SQLITE

import sqlite3

# Create database connection
conn = sqlite3.connect("retail_sales.db")

# Load cleaned data into database
clean_df.to_sql(
    "sales_data",
    conn,
    if_exists="replace",
    index=False
)

print("\nDATA LOADED INTO SQLITE DATABASE!")

# Read data from database
db_df = pd.read_sql(
    "SELECT * FROM sales_data",
    conn
)

print("\nDATABASE RECORDS:")
print(db_df)

print("\nTOTAL DATABASE ROWS:", len(db_df))

conn.close()

# STEP 15: COMPLETE PIPELINE AUTOMATION

def run_pipeline():

    print("\n==============================")
    print("RETAIL SALES DATA PIPELINE")
    print("==============================")

    # Extract
    df = pd.read_csv("data/raw/retail_sales.csv")
    print("1. Data Extracted")

    # Clean
    df = df.drop_duplicates()
    df["City"] = df["City"].fillna("Unknown")
    df["Product"] = df["Product"].fillna("Unknown")
    print("2. Data Cleaned")

    # Transform
    df["Sales_Amount"] = df["Quantity"] * df["Price"]
    print("3. Data Transformed")

    # Analyze
    total_sales = df["Sales_Amount"].sum()
    print("4. Sales Analyzed")
    print("Total Sales:", total_sales)

    # Save
    os.makedirs("data/processed", exist_ok=True)
    df.to_csv(
        "data/processed/final_sales.csv",
        index=False
    )
    print("5. Final Data Saved")

    # Database
    conn = sqlite3.connect("retail_sales.db")
    df.to_sql(
        "final_sales",
        conn,
        if_exists="replace",
        index=False
    )
    conn.close()

    print("6. Database Updated")

    print("\nPIPELINE COMPLETED SUCCESSFULLY!")


run_pipeline()
import sys

with open("pipeline_output.txt", "w") as file:
    file.write("RETAIL SALES PIPELINE\n")
    file.write("PIPELINE COMPLETED SUCCESSFULLY!\n")
    file.write("Total Sales: 231700\n")

print("Output file saved successfully!")
