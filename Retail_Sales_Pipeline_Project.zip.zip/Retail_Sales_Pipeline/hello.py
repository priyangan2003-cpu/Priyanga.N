print("Hellow World")
print("Welcome to Python")
print("My first progrm in VS Code")